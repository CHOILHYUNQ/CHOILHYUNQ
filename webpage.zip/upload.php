<?php header("content-type:text/html; charset=utf-8");
//태원
// $target_dir = "C:\Users\Taewon\Desktop\upload";

//일현
$target_dir = "C:\Users\hyun\PycharmProjects\eye\known";


$image = $_POST["image"];
$name = $_POST["name"];

$menu = $_POST["sinceSpinner"];
$temper = $_POST["sinceSpinner2"];
$size = $_POST["sinceSpinner3"];
$count = $_POST["sinceSpinner4"];
$regdate=date("Y/m/d  H:i:s",time()); //날짜,시간


if($menu=='Americano'){
	$price = 2500 * (int)$count;
}
else if($menu=='Cappuccino'){
	$price = 2800 * (int)$count;
}
else if($menu=='CafeLatte'){
	$price = 2700 * (int)$count;
}
else if($menu=='Vanila Latte'){
	$price = 3000 * (int)$count;
}
else if($menu=='Caramel'){
	$price = 2700 * (int)$count;
}
else if($menu=='Cafe Mocha'){
	$price = 2900 * (int)$count;
}



if(!file_exists($target_dir)){
	// create upload/images folder
	mkdir($target_dir, 0777, true);
}

if($menu[0]=='S' or $temper[0]=='S' or $size[0]=='S' or $count[0]=='S'){
	// $target_dir = $target_dir ."/". "taewon" . "_". time() . ".jpg";
	$target_dir = $target_dir ."/". "$name" . ".jpg";
	file_put_contents($target_dir, base64_decode($image));

	//태원
	// $connect=mysqli_connect('localhost','root','dgu1234!','kiosk');
	//일현
	// $connect=mysqli_connect('localhost','root','dgu1234!','kiosk', 3309);

	// 쿼리 전송 
   // $query="insert into android(name,regdate) values('$name','$regdate')";
   
   // $result = mysqli_query($connect, $query);
   // if($result === false){
   //     echo mysqli_error($connect);
   // }

}
else{
	//태원
	// $connect=mysqli_connect('localhost','root','dgu1234!','kiosk');
	//일현
	$connect=mysqli_connect('localhost','root','dgu1234!','kiosk', 3309);

	// 쿼리 전송 
   $query="insert into android(name,menu,temper,size,count,price,regdate) values('$name','$menu','$temper','$size','$count','$price','$regdate')";
   
   $result = mysqli_query($connect, $query);
   if($result === false){
       echo mysqli_error($connect);
   }

   	$target_dir = $target_dir ."/". "$name" . ".jpg";
	file_put_contents($target_dir, base64_decode($image));
}




// if(file_put_contents($target_dir, base64_decode($image))) { 
	// echo json_encode([
	// 	"Message" => "The file has been uploaded.",
	// 	"Status" => "OK"
	// ]);
// } 
// else{
	// echo json_encode([
	// 	"Message" => "Sorry, there was an error uploading your file.",
	// 	"Status" => "Error"
	// ]);
// }
?>