<!DOCTYPE HTML>

<html>

<head>
    <title>캡딱두</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!-- 5초 뒤에 사이트로 이동 -->
    <!-- <meta http-equiv="refresh" content="5; url=http:./checkface.php"> -->

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.dropotron.min.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-layers.min.js"></script>
    <script src="js/init.js"></script>
    <script src="js/app.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <noscript>
        <link rel="stylesheet" href="css/skel.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style-wide.css" />
    </noscript>

  
  <!-- <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->

    <style>
        #border:hover {
            border: 5px solid #6b6b6b;
            ;
        }
    </style>
    
</head>


<body>
    <!-- Wrapper -->
    <div class="wrapper style1">
        <!-- Header -->
        <div id="header" class="skel-panels-fixed">
            <div id="logo">
                <h1 id="checkcart2" style="font-size : 2.8em"><a href="./index.php">
                    Dongguk Cafe
                </a></h1>
                <span class="tag">by 캡딱두</span>
            </div>
            <nav id="nav">
                <ul>
                    <li class="active"><a href="./index.php">Homepage</a></li>
                </ul>
            </nav>
        </div>

        <div id="banner" class="container">
            <section>
               <!--  <p style="font-size : 4.3em; color:black;" >사진을 선택해도 주문이 가능합니다!</p> -->
               <!--  <a onclick="show('ice');" class="button xlarge">Iced</a>　
                <a onclick="show('hot');" class="button xlarge">Hot</a>　 -->
                <br><br><br>
                <a class="button xlarge" href="./open.php"> <br><br><br>주문하기<br><br><br></a>
            </section>
        </div>  

        <br><br>
    </div>


    <br /><br /><br />
 

</body>


</html>
